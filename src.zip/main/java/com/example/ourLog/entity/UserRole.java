package com.example.ourLog.entity;

public enum UserRole {
  GUEST, USER, ADMIN
  
}
