package com.example.ourLog.repository;

import com.example.ourLog.entity.Question;
import com.example.ourLog.entity.User;
import com.example.ourLog.repository.search.SearchRepository;
import com.example.ourLog.security.dto.UserAuthDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface QuestionRepository extends JpaRepository<Question, Long>, SearchRepository {

  @Query("select q from Question q where q.questionId = :questionId")
  Optional<Question> findQuestionById(@Param("questionId") Long questionId);

  @Query("select q, a from Question q " +
          "left join Answer a on a.question = q " +
          "where q.questionId = :questionId and a.user = :user ")
  List<Object[]> getQuestionWithAnswer(@Param("questionId") Long questionId,
                                       @Param("user") UserAuthDTO user);

  @Query("select q from Question q")
  Page<Question> getQuestionList(Pageable pageable);

  // Answer 삭제용
  @Modifying
  @Query("delete from Answer a where a.question.questionId = :questionId")
  void deleteAnswersByQuestionId(@Param("questionId") Long questionId);

  // Question 삭제용
  @Modifying
  @Query("delete from Question q where q.questionId = :questionId")
  void deleteQuestionByQuestionId(@Param("questionId") Long questionId);

  List<Question> findByUser(User user);
}